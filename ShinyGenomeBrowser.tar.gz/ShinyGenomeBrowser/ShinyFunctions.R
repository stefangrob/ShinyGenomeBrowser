#####SHINY FUNCTIONS########

f.rev.compl <- function(x){
  res <- paste(chartr("ACTG","TGAC",rev(unlist(strsplit(as.character(x), split="")))),collapse="")
  return(res)
}

f.gff.conversion <- function(gffFile = "/Users/stefan/CloudStation/Bioinformatik/Annotations/TAIR10_GFF3_genes_transposons_noChr.gff", featureOI = c("gene", "transposable_element_gene","transposable_element", "pseudogene", "miRNA", "ncRNA", "snoRNA", "tRNA", "rRNA")){
  gff <- gffRead(gffFile, nrows = -1)
  colCodeList <- list(gene = rgb(0, 0, 0, 255,max = 255), transposable_element_gene = rgb(217,95,2, 255,max = 255), pseudogene = rgb(117,112,179, 255,max = 255), miRNA = rgb(231,41,138, 255,max = 255), ncRNA = rgb(27,158,119, 255,max = 255), exon = "slateblue4")#, snoRNA = rgb(, 255,max = 255))
  gff_anno_oi <- gff[gff[,3] %in% featureOI,]
  gff_anno_oi$name <- getAttributeField(gff_anno_oi$attributes, "Name")
  colnames(gff_anno_oi)[1] <- "chrom"
  gff_anno_oi <- gff_anno_oi[gff_anno_oi$chrom %in% chromosomes,]
}

f.gff.loader <- function(gffPATH = "./Data/TAIR10_GFF3_genes_transposons_noChr.gff", chrom = "Chr1", start = 1e6, end = 1.05e6, featureOI = c("gene", "transposable_element_gene","transposable_element", "pseudogene", "miRNA", "ncRNA", "snoRNA", "tRNA", "rRNA", "exon")) {
  gff <- gffRead(gffPATH, nrows = -1)
  featOUT <- featureOI
  gff <- gff[gff[,3] %in% featOUT,]
  gff <- gff[gff$seqname == chrom & gff$start > start-1e4 & gff$end < end+1e4,]
  gff$name <- getAttributeField(gff$attributes, "Name")
  return(gff)
}


f.reads.extract.minimal <- function(chrom = chrom, start = start, end = end, bamPATHin = bamPATH, threads = 4){
  x <- system(paste("samtools view --threads ",threads," ",bamPATHin," ",chrom,":",start,"-",end," | awk '$6 !~ /S/ || $1 ~ /@/' | awk 'OFS=\"\t\" {print $2, $4, length($10)}'", sep = ""), intern = TRUE)
  if (length(x)==0){return(data.frame("strand" = as.numeric(c()), "pos" = numeric(), "length" = numeric(), stringsAsFactors = FALSE))}
  else {
    df <-read.table(text = x, header=FALSE, stringsAsFactors = FALSE, sep = "\t")
    colnames(df) <- c("strand", "pos", "length")
    return(df)
  }
}

f.create.cov.vec <- function(reads=sub, VecStart=start, VecEnd=end){#this one is surprisingly faster than the minimal version with apply.....
  print(paste("calculating coverage from ",VecStart," to ", VecEnd, sep = ""))
  covVec <- rep(0, length(c(VecStart:VecEnd)))
  names(covVec) <- c(VecStart:VecEnd)
  covList <- list()
  for (n in c(1:nrow(reads))){ ##make a matrix, containing each row a vector with the coordiantes covered by each read
    covList[[n]] <- as.vector(c(as.numeric(as.vector(reads$pos[n])):(as.numeric(as.vector(reads$pos[n]))+as.numeric(as.vector(reads$length[n]))-1)))
  }
  covVecTemp <- as.vector(unlist(covList))##create a vector that contains all the covered coordinates
  covTabTemp <- table(covVecTemp)
  covTab <- covTabTemp[which(as.numeric(names(covTabTemp)) <= VecEnd & as.numeric(names(covTabTemp)) >= VecStart)]
  covVec[names(covTab)] <- as.numeric(covTab)
  return(covVec)
}


f.create.cov.vec.minimal <- function(reads=sub, VecStart=start, VecEnd=end){
  covVec <- rep(0, length(c(VecStart:VecEnd)))
  names(covVec) <- c(VecStart:VecEnd)
  cov <- table(unlist(apply(f, 1, function(x) c(x[2]:(x[2]+x[3]-1)))))
  cov <- cov[which(as.numeric(names(cov)) <= VecEnd & as.numeric(names(cov)) >= VecStart)]
  covVec[names(cov)] <- as.numeric(cov)
  return(covVec)
}



#### read gff files 
gffRead <- function(gffFile, nrows = -1) {
  cat("Reading ", gffFile, ": ", sep="")
  gff = read.table(gffFile, sep="\t", as.is=TRUE, quote="",
                   header=FALSE, comment.char="#", nrows = nrows,
                   colClasses=c("character", "character", "character", "integer","integer","character", "character", "character", "character"))
  colnames(gff) = c("seqname", "source", "feature", "start", "end", "score", "strand", "frame", "attributes")
  cat("found", nrow(gff), "rows with classes:", paste(sapply(gff, class), collapse=", "), "\n")
  #stopifnot(!anyis.na(gff$start)), !anyis.na(gff$end)))
  return(gff)
}

#### extract info from "attributes" field in gff files
getAttributeField <- function(x, field, attrsep = ";"){
  s = strsplit(x, split = attrsep, fixed = TRUE) 
  sapply(s, function(atts){
    a = strsplit(atts, split = "=", fixed = TRUE)
    m = match(field, sapply(a, "[", 1))
    if (!is.na(m)){
      rv = a[[m]][2] } 
    else {
      rv = as.character(NA) }
    return(rv) 
  }) 
}

f.library.size <- function(bam = bamfile){
  sum(read.table(text = system(paste("samtools idxstats ",bam, sep = ""), intern=TRUE), sep = "\t", header = FALSE, stringsAsFactors = FALSE)[,3])
}


f.coverage.plotter <- function(inDAT = pooled, stranded=TRUE, sizes=c(21,22,23,24), rpm = TRUE, TotLibReads = TotalReadsPerSample[[name]], start = start, end = end, ylim=NULL, title = name, normFac = NULL){
  require(RColorBrewer)
  #dat <- as.data.frame(cbind(as.vector(inDAT[,1]),as.numeric(as.vector(inDAT[,2])), as.numeric(as.vector(inDAT[,3])),as.character(inDAT[,4]), as.character(inDAT[,5])),stringsAsFactors=FALSE)
  dat <- as.data.frame(cbind(as.vector(inDAT[,1]),as.numeric(as.vector(inDAT[,2])), as.numeric(as.vector(inDAT[,3]))),stringsAsFactors=FALSE)
  
  colnames(dat) <- colnames(inDAT)
  colorsNeeded <- length(unique(dat[dat$length %in% sizes,]$length))
  colPattern <- f.create.col.list(n = colorsNeeded, transparancy = 0.5, style="RdYlBu")
  colList <- as.list(colPattern)
  names(colList) <- sort(unique(dat[dat$length %in% sizes,]$length))
  if (stranded == TRUE){
    plusCov <- as.data.frame(inDAT[inDAT$strand==0,], stringsAsFactors = FALSE)
    plusCov <- plusCov[plusCov$length %in% sizes,]
    minusCov <- as.data.frame(inDAT[inDAT$strand==16,], stringsAsFactors = FALSE)
    minusCov <- minusCov[minusCov$length %in% sizes,]
    
    covPLUSlist <- list()
    covMINUSlist <- list()
    sizes <- intersect(sizes, unique(dat$length))
    readsPerSizeList <- list()
    for (u in c(1:length(sizes))){
      print(paste("processing of size:",sizes[u],sep=""))
      subPlus <- plusCov[plusCov$length==sizes[u],]
      subMinus <- minusCov[minusCov$length==sizes[u],]
      if (rpm == TRUE) {
        if (nrow(subPlus) > 0){ 
          covPLUSlist[[u]] <- (f.create.cov.vec(reads=subPlus, VecStart= start, VecEnd = end)/TotLibReads)*1e6
          covPLUSlist[[u]][c(1,length(covPLUSlist[[u]]))] <- 0
        }
        else {covPLUSlist[[u]] <- 0}
        if (nrow(subMinus)>0){
          covMINUSlist[[u]] <- (-f.create.cov.vec(reads=subMinus, VecStart=start, VecEnd=end)/TotLibReads)*1e6
          covMINUSlist[[u]][c(1,length(covMINUSlist[[u]]))] <- 0
        }
        else {covMINUSlist[[u]] <- 0}
        readsPerSizeList[[u]] <- sum(c(covPLUSlist[[u]],covMINUSlist[[u]]), na.rm = FALSE)
      }
      else {
        if (nrow(subPlus)>0){
          covPLUSlist[[u]] <- f.create.cov.vec(reads=subPlus, VecStart=start, VecEnd=end)
          covPLUSlist[[u]][c(1,length(covPLUSlist[[u]]))] <- 0
        }
        if (nrow(subMinus)>0){
          covMINUSlist[[u]] <- -f.create.cov.vec(reads=subMinus, VecStart=start, VecEnd=end)
          covMINUSlist[[u]][c(1,length(covMINUSlist[[u]]))] <- 0
        }
        readsPerSizeList[[u]] <- sum(c(covPLUSlist[[u]],covMINUSlist[[u]]), na.rm = FALSE)
      }
    }
    plusTAB <- as.data.frame(do.call("cbind", covPLUSlist), stringsAsFactors = FALSE)
    if (!(is.null(normFac))){plusTAB <- plusTAB/normFac}
    colnames(plusTAB) <- sizes
    minusTAB <- as.data.frame(do.call("cbind", covMINUSlist), stringsAsFactors = FALSE)
    if (!(is.null(normFac))){minusTAB <- minusTAB/normFac}
    colnames(minusTAB) <- sizes
    
    if (!is.null(ylim)){ylim <- ylim}
    else {ylim <- max(c(unlist(covPLUSlist),abs(unlist(covMINUSlist))))}
    axTicks(side=2, axp = NULL, usr = c(0:ylim), log = NULL, nintLog = NULL)
    yAxAT <- pretty(c(-ylim,ylim), n = 5)
    yAxAT <- yAxAT[abs(yAxAT) < ylim]
    plot(c(start:end),rep(1, length(c(start:end))), type="n", xlim=c(start, end), ylim = c(-ylim,ylim), yaxt="n", ylab="rpm", xlab="", bty="n", xaxt="n")
    abline(h = yAxAT, lty="dashed", col = rgb(0.1,0.1,0.1,0.5))
    axis(2, at=yAxAT, labels= abs(yAxAT))
    counter <- length(sizes)
    for (i in c(1:(length(sizes)-1))){
      if (counter > 1){
        
        ToPlotPlus <- rowSums(plusTAB[,c(1:counter)])
        ToPlotMinus <- rowSums(minusTAB[,c(1:counter)])
        counter <- counter - 1
        color <- colList[[as.character(rev(sizes)[i])]]
        polygon(as.numeric(rownames(plusTAB)),as.numeric(ToPlotPlus), col = color, border = NA)
        polygon(as.numeric(rownames(minusTAB)),as.numeric(ToPlotMinus), col = color, border = NA)
        
      } 
      if (counter == 1) {
        color <- colList[[as.character(sizes[1])]]
        polygon(as.numeric(rownames(plusTAB)),as.numeric(plusTAB[,1]), col = color, border=NA)
        polygon(as.numeric(rownames(minusTAB)),as.numeric(minusTAB[,1]), col = color, border=NA)			
      }
    }
    
    
    #		plotingSequence <- names(unlist(readsPerSizeList)[order(unlist(readsPerSizeList))])
    #		for (size in plotingSequence){
    # 			#points(as.numeric(names(covPLUSlist[[size]])),covPLUSlist[[size]], type="h", col=colList[[size]])
    # 			polygon(as.numeric(names(covPLUSlist[[size]])),as.numeric(covPLUSlist[[size]]), col=colList[[as.character(size)]], border=NA)
    # 			#points(as.numeric(names(covMINUSlist[[size]])),covMINUSlist[[size]], type="h", col=colList[[size]])
    # 			polygon(as.numeric(names(covMINUSlist[[size]])),covMINUSlist[[size]], col=colList[[as.character(size)]], border=NA)
    # 		}
    abline(h = 0)
    legend("topright", legend = as.character(sizes), pch = 15, col= unlist(colList), title = "sizes", bty = "n")
    legend("topleft", legend = title, bty = "n")
  }
  else {
    inDAT <- inDAT[inDAT$length %in% sizes,]
    covList <- list()
    readsPerSizeList <- list() #this list is need to later decide which size to plot first (the one with the highest numbers of reads....
    for (u in unique(inDAT$length)){
      sub <- inDAT[inDAT$length==u,]
      if (rpm == TRUE) {
        temp <- if (nrow(sub)>0){(f.create.cov.vec(reads=sub, VecStart=start, VecEnd=end)/TotLibReads)*1e6}
        covList[[u]] <- temp
        readsPerSizeList[[u]] <- sum(temp)
      }
      else {
        temp <- if (nrow(sub)>0){f.create.cov.vec(reads=sub, VecStart=start, VecEnd=end)/TotLibReads}
        covList[[u]] <- temp
        readsPerSizeList[[u]] <- sum(temp)
      }
    }
    covTAB <- as.data.frame(do.call("cbind", covList), stringsAsFactors = FALSE)
    
    if (!(is.null(normFac))){covTAB <- covTAB/normFac}
    if (!is.null(ylim)){ylim <- ylim}
    else {ylim <- max(unlist(covList))}
    axTicks(side=2, axp = NULL, usr = c(0:ylim), log = NULL, nintLog = NULL)
    yAxAT <- pretty(c(0,ylim), n = 5)
    yAxAT <- yAxAT[abs(yAxAT) < ylim]
    plot(c(start:end),rep(1, length(c(start:end))), type="n", xlim=c(start, end), ylim = c(0,ylim), yaxt="n", ylab="rpm", xlab="coordinate", bty="n")
    abline(h = yAxAT, lty="dashed", col = rgb(0.1,0.1,0.1,0.5))
    axis(2, at=yAxAT, labels= abs(yAxAT))
    
    plotingSequence <- names(unlist(readsPerSizeList)[order(unlist(readsPerSizeList))])#####THIS IS NOT WORKING - NO NAMES - GIVES NULL
    for (size in plotingSequence){
      points(as.numeric(names(covList[[size]])),covList[[size]], type="h", col=colList[[size]])
    }
    
    abline(h = 0)
    legend("topright", legend = as.character(sizes), pch = 15, col= unlist(colList), title = "sizes", bty = "n")
    legend("topleft", legend = title, bty = "n")
    #return(covTAB)
  }
}

f.create.col.list <- function(n = NULL, transparancy = 0.5, style="BrBG"){
  if (n > 11) {rainbow(n = n, alpha = transparancy)}
  else {if (n < 3){x <- 3} else {x <- n}
    colPattern <- brewer.pal(n, name=style)
    colTAB <- col2rgb(colPattern, alpha=TRUE)
    colVec <- as.vector(apply(sapply(colPattern, col2rgb)/255, 2, function(x) rgb(x[1], x[2], x[3], alpha=transparancy)))
    return(colVec)
  }
}

f.plot.gff.anno <<- function(chrom, start, end, gff, label = FALSE){
    colCodeList <- list(gene = rgb(0, 0, 0, 255,max = 255), transposable_element_gene = rgb(217,95,2, 255,max = 255), pseudogene = rgb(117,112,179, 255,max = 255), miRNA = rgb(231,41,138, 255,max = 255), ncRNA = rgb(27,158,119, 255,max = 255), exon = "slateblue4")
    plot(1, type="n", ylim=c(0,4), xlab=chrom, yaxt="n", ylab="", bty = "n", xlim = c(start, end))
    anno <- gff[gff$seqname == chrom & gff$start > (start-5e3) & gff$end < (end+5e3),]
    annoForward <- anno[anno$strand == "+" & anno$feature != "exon", ]
    annoReverese <- anno[anno$strand == "-" & anno$feature != "exon", ]
    forwardExon <- anno[anno$strand == "+" & anno$feature == "exon", ]
    reverseExon <- anno[anno$strand == "-" & anno$feature == "exon", ]
    if (nrow(annoForward)>0){
      arrows(annoForward$start, 2, annoForward$end, 2, length = 0.1)
      if (label == TRUE) {
		for(i in c(1:nrow(annoForward))) {text(mean(c(annoForward$start[i], annoForward$end[i])), 2.5, labels = annoForward$name[i])}
		}
    }
    if (nrow(forwardExon)>0){arrows(forwardExon$start, 2.25, forwardExon$end, 2.25, length = 0, col = colCodeList[["exon"]], lwd =3)}
    if (nrow(annoReverese)>0){
      arrows(annoReverese$end, 1, annoReverese$start, 1, length = 0.1)
      if (label == TRUE) {
		for(i in c(1:nrow(annoReverese))) {text(mean(c(annoReverese$start[i],annoReverese$end[i])), 1.5, labels = annoReverese$name[i])}
		}
    }
    if (nrow(reverseExon)>0){arrows(reverseExon$end, 1.25, reverseExon$start, 1.25, length = 0, col = colCodeList[["exon"]], lwd =3)}
}


f.retrieve.gene.info <- function(x = "AT1G18390"){
	(system(paste("awk 'OFS=\"\t\" $1 ~ /",x,"/ { print $0}' /Users/stefan/CloudStation/Bioinformatik/Annotations/gene_description_20131231.txt", sep = ""), intern = TRUE))
}

f.coverage.plotter.mRNA <- function(inDAT = pooled, stranded=TRUE, rpm = TRUE, TotLibReads = TotalReadsPerSample[[name]], start=start, end=end, ylim=NULL, title = name, normFac=NULL, colors = c("navyblue","firebrick2")){
		
# 	if (stranded == TRUE){
# 		plusCov <- as.data.frame(inDAT[inDAT$strand==0,], stringsAsFactors = FALSE)
# 		minusCov <- as.data.frame(inDAT[inDAT$strand==16,], stringsAsFactors = FALSE)
# 		
# 		if (rpm == TRUE) {
# 			covPLUSvec <- if (nrow(plusCov)>0){(f.create.cov.vec(reads=plusCov, VecStart=start, VecEnd=end)/TotLibReads)*1e6}
# 			if (!is.null(normFac)){covPLUSvec <- covPLUSvec/normFac}
# 			covMINUSvec <- if (nrow(minusCov)>0){(-f.create.cov.vec(reads=minusCov, VecStart=start, VecEnd=end)/TotLibReads)*1e6}
# 			if (!is.null(normFac)){covMINUSlist[[u]] <- covMINUSlist[[u]]/normFac}
# 		}	else	{
# 			covPLUSvec <- if (nrow(plusCov)>0){f.create.cov.vec(reads=plusCov, VecStart=start, VecEnd=end)}
# 			if (!is.null(normFac)){covPLUSvec <- covPLUSvec/normFac}
# 			covMINUSvec <- if (nrow(minusCov)>0){-f.create.cov.vec(reads=minusCov, VecStart=start, VecEnd=end)}
# 			if (!is.null(normFac)){covMINUSvec <- covMINUSvec/normFac}
# 		}
# 		if (!is.null(ylim)){ylim <- ylim}
# 		else {ylim <- max(c(covPLUSvec,abs(covMINUSvec)))}
# 		axTicks(side=2, axp = NULL, usr = c(0:ylim), log = NULL, nintLog = NULL)
# 		yAxAT <- pretty(c(-ylim,ylim), n = 10)
# 		yAxAT <- yAxAT[abs(yAxAT) < ylim]
# 		plot(c(start:end),rep(1, length(c(start:end))), type="n", xlim=c(start, end), ylim = c(-ylim,ylim), yaxt="n", ylab="rpm", xlab="coordinate", bty="n", xaxt="n")
# 		abline(h = yAxAT, lty="dashed", col = rgb(0.1,0.1,0.1,0.5))
# 		axis(2, at=yAxAT, labels= abs(yAxAT))
# 		
# 		if (length(covPLUSvec) > 0){
# 			covPLUSvec <- covPLUSvec[order(names(covPLUSvec))]
# 			covPLUSvec[1] <- 0
# 			covPLUSvec[length(covPLUSvec)] <- 0
# 			polygon(as.numeric(names(covPLUSvec)),covPLUSvec, col=colors[1], border=NA)
# 		}
# 		if (length(covMINUSvec) > 0){
# 			covMINUSvec <- covMINUSvec[order(names(covMINUSvec))]
# 			covMINUSvec[1] <- 0
# 			covMINUSvec[length(covMINUSvec)] <- 0
# 			polygon(as.numeric(names(covMINUSvec)),covMINUSvec, col=colors[2], border=NA)
# 		}
# 		
# 		#points(as.numeric(names(covPLUSvec)),covPLUSvec, type="h", col="navyblue")
# 		
# 		#points(as.numeric(names(covMINUSvec)),covMINUSvec, type="h", col="firebrick2")
# 		
# 		abline(h = 0)
# 		legend("topleft", legend = title, bty = "n")
# 	}
# 	else {
		covVec <- (f.create.cov.vec(reads=inDAT, VecStart=start, VecEnd=end)/TotLibReads)*1e6
		if (!is.null(normFac)){covVec <- covVec/normFac}
		if (!is.null(ylim)){ylim <- ylim}
		else {ylim <- max(covVec)}
		axTicks(side=2, axp = NULL, usr = c(0:ylim), log = NULL, nintLog = NULL)
		yAxAT <- pretty(c(0,ylim), n = 5)
		yAxAT <- yAxAT[abs(yAxAT) < ylim]
		plot(0,0, type="n", xlim=c(start, end), ylim = c(0,ylim), yaxt="n", ylab="rpm", xlab="", bty="n", xaxt="n")
		#abline(h = yAxAT, lty="dashed", col = rgb(0.1,0.1,0.1,0.5))
		axis(2, at=yAxAT, labels= abs(yAxAT))

		if (length(covVec) > 0){
			x <- names(covVec)
			y <- as.vector(covVec[order(names(covVec))])
			y[1] <- 0
			y[length(y)] <- 0
			#polygon(c(as.numeric(names(covVec)),rev(as.numeric(names(covVec)))),c(covVec, rep(0, length(covVec))), col=colors[1], border=NA) ## produces still weird poylgon, likely something wrong with ends -does not happen by direct plotting!
			polygon(as.numeric(x),y, col=colors[1], border=NA)
			#points(as.numeric(names(covVec)),covVec, type = "h", col = rgb(255,0,0,100, max = 255))
		}
		abline(h = yAxAT, lty="dashed", col = rgb(0.1,0.1,0.1,0.5))
		#legend("topleft", legend = title, bty = "n")
# 	}
}



f.binned.plotter.sRNA <- function(inTAB = pooled, binsize = 20, start = start, end = end, sizes = c(21,22,23,24), xlim = PlotXlim, ylimit = "internal", main = NULL, normFac=NULL, correct = FALSE, rpm = FALSE, TotLibReads = NULL){	
  inTAB <- inTAB[inTAB$length %in% sizes,]
  colPatternFill <- rainbow(length(sort(unique(inTAB$length))), alpha = 0.75)
  colListFill <- as.list(colPatternFill)
  names(colListFill) <- as.character(sort(unique(inTAB$length)))
  colPatternBorder <- rainbow(length(sort(unique(inTAB$length))), alpha = 1)
  colListBorder <- as.list(colPatternBorder)
  names(colListBorder) <- as.character(sort(unique(inTAB$length)))
  bins <- seq(start, end, by = binsize)
  BinsTab <- as.data.frame(cbind(bins, rep(0, length(bins))))
  if (rpm == TRUE) {BinsTAB_Total <- f.bin.maker(inDAT = inTAB, binsize = binsize, BinsTab = BinsTab, DoRPM = TRUE, NumbReadsToRPM = TotLibReads)}
  else {BinsTAB_Total <- f.bin.maker(inDAT = inTAB, binsize = binsize, BinsTab = BinsTab, DoRPM = FALSE, NumbReadsToRPM = NULL)}
  if (ylimit == "internal") {ylimSetting <- c(-max(BinsTAB_Total[BinsTAB_Total[["pos"]] >= xlim[1] &  BinsTAB_Total[["pos"]] <= xlim[2],"readsPerBin"]), max(BinsTAB_Total[BinsTAB_Total[["pos"]] >= xlim[1] &  BinsTAB_Total[["pos"]] <= xlim[2],"readsPerBin"]))}
  else {ylimSetting <- ylimit}
  if (correct == TRUE){
    if (max(BinsTAB_Total$readsPerBin) > ylimSetting[2]) {ylimSetting <- c(-max(BinsTAB_Total[BinsTAB_Total[["pos"]] >= xlim[1] &  BinsTAB_Total[["pos"]] <= xlim[2],"readsPerBin"]), max(BinsTAB_Total[BinsTAB_Total[["pos"]] >= xlim[1] &  BinsTAB_Total[["pos"]] <= xlim[2],"readsPerBin"]))}
  }
  
  minus <- inTAB[inTAB[["strand"]] == 16,]
  plus <- inTAB[inTAB[["strand"]] == 0,]
  minusList <- list()
  plusList <- list()
  plot(BinsTab[,1], BinsTab[,2], type="n", xlim = xlim, ylim = ylimSetting, xaxt="n", xlab="")
  for (u in unique(inTAB[["length"]])){
    minusTemp <- minus[minus[["length"]] == u,]
    if (rpm==TRUE){minusTemp <- f.bin.maker(inDAT = minusTemp, binsize = binsize, BinsTab = BinsTab, DoRPM = TRUE, NumbReadsToRPM = TotLibReads)}
    else {minusTemp <- f.bin.maker(inDAT = minusTemp, binsize = binsize, BinsTab = BinsTab, DoRPM = FALSE, NumbReadsToRPM = NULL)}
    plusTemp <- plus[plus[["length"]] == u,]
    if (rpm == TRUE) {plusTemp <- f.bin.maker(inDAT = plusTemp, binsize = binsize, BinsTab = BinsTab, DoRPM = TRUE, NumbReadsToRPM = TotLibReads)}
    else {plusTemp <- f.bin.maker(inDAT = plusTemp, binsize = binsize, BinsTab = BinsTab, DoRPM = FALSE, NumbReadsToRPM = NULL)}
    if (!is.null(normFac)){
      minusTemp$readsPerBin <- minusTemp$readsPerBin/normFac
      plusTemp$readsPerBin <- plusTemp$readsPerBin/normFac
    }
    if (nrow(minusTemp) > 0){polygon(minusTemp$pos, -minusTemp$readsPerBin, xlim = xlim, ylim = ylimSetting, col = colListFill[[as.character(u)]], border=NA, lwd = 1)}
    if (nrow(plusTemp) > 0){polygon(plusTemp$pos, plusTemp$readsPerBin, xlim = xlim, ylim = ylimSetting, col = colListFill[[as.character(u)]], border=NA, lwd = 1)}
  }
  lines(xlim,c(0,0))
  legend("topright", legend = paste(names(colListBorder), "nt", sep=""), col = unlist(colListBorder), pch=16, bty = "n")
  if (!is.null(main)){legend("topleft", legend=main, bty="n")}
}


f.bin.maker <- function(inDAT, binsize, BinsTab = BinsTab, DoRPM = FALSE, NumbReadsToRPM = NULL){
  inDAT$bins <- floor(as.numeric(as.vector(inDAT[["pos"]]))/binsize)*binsize
  temp <- ddply(inDAT, "bins", nrow)
  if (nrow(temp) > 0){
    for (i in c(1:nrow(temp))){
      BinsTab[BinsTab[,1]==temp[i,1],2] <- temp[i,2]
    }
    colnames(BinsTab) <- c("pos", "readsPerBin")
    if (DoRPM == TRUE) {print(NumbReadsToRPM);BinsTab$readsPerBin <- (BinsTab$readsPerBin/NumbReadsToRPM)*1e6}
    return(BinsTab)
  }
  else{
    BinsTab <- data.frame("pos" = numeric(), "readsPerBin" = numeric(), stringsAsFactors = FALSE)
    if (DoRPM == TRUE) {print(NumbReadsToRPM);BinsTab$readsPerBin <- (BinsTab$readsPerBin/NumbReadsToRPM)*1e6}
    return(BinsTab)
  }
}




f.binned.plotter.minimal <- function(inBAM, binsize = NULL, chr = "Chr1", start = start, end = end, xlim = c(start, end), ylimit = NULL, main = NULL, rpm = FALSE){
	if (is.null(binsize)){binsize <- (end-start)/200}
	bedStart <- as.character(format(round(seq(start, end-binsize, by = binsize), digits = 0), scientific = F, justify = "none", trim = TRUE))
	bedEnd <- as.character(format(round(seq(start+binsize, end, by = binsize), digits = 0), scientific = F, justify = "none", trim = TRUE))
	roiTAB <- matrix(c(rep(chr, length(bedStart)), bedStart, bedEnd), ncol = 3)
	write.table(roiTAB, paste(getwd(),"/bed.bed", sep =""), sep = "\t", col.names = FALSE, row.names = FALSE, quote = FALSE)
	inTAB <- read.table(text = system(paste("samtools bedcov ",getwd(),"/bed.bed " ,inBAM, sep = ""), intern = TRUE), sep = "\t")
	system(paste("rm ",getwd(),"/bed.bed", sep = ""))
	if (rpm == TRUE) {
		libSize <- f.library.size(inBAM)
		inTAB[,4] <- inTAB[,4]/libSize
	}
	if (is.null(ylimit)) {ylimSetting <- c(0, max(inTAB[,4]))}
	else {ylimSetting <- c(0,ylimit)}
	plot(inTAB[,2], inTAB[,4], type="h", xlim = xlim, ylim = ylimSetting, xaxt="n", xlab="", ylab = "", bty = "n")
	polygon(c(inTAB[,2], rev(inTAB[,2])), c(inTAB[,4], rep(0, nrow(inTAB))), xlim = xlim, ylim = ylimSetting, col = "blue", border=NA, lwd = 1)
	lines(xlim,c(0,0))
	if (!is.null(main)){legend("topleft", legend=main, bty="n")}
}
f.translate.chrom.pos.vector.to.index.minimal <- function(positionVec, binSize = binsize) {
	out <- floor(positionVec/binsize)
	return(out)
}

f.plot.gff.anno.binned <- function(gff = gff_anno_oi, chrom = input$chrom, start = input$start, end = input$end, binsize = NULL){
  gff <- gff[gff[,1] == chrom & gff[,4] >= start & gff[,5] <= end,]
  genes <- gff[gff$feature == "gene",]
  TEs <- gff[gff$feature %in% c("transposable_element", "transposable_element_gene"),]
  if (is.null(binsize)){binsize <- (end-start)/200}
  genes$bin <- f.translate.chrom.pos.vector.to.index.minimal(genes$start, binSize = binsize)
  TEs$bin <- f.translate.chrom.pos.vector.to.index.minimal(TEs$start, binSize = binsize)
  binsTAB <- data.frame(round(seq(start,end, by = binsize), digits = 0), floor(round(seq(start,end, by = binsize), digits = 0)/binsize), rep(0,length(seq(start,end, by = binsize))), rep(0,length(seq(start,end, by = binsize))))
  colnames(binsTAB) <- c("pos","bin", "numbGenes", "numbTEs")
  genesPerBin <- ddply(genes, "bin", function(x) nrow(x))
  TEsPerBin <- ddply(TEs, "bin", function(x) nrow(x))
  binsTAB[binsTAB[,2] %in% genesPerBin[,1],"numbGenes"] <- genesPerBin[,2]
  binsTAB[binsTAB[,2] %in% TEsPerBin[,1],"numbTEs"] <- TEsPerBin[,2]
  ylim <- c(-max(binsTAB[,"numbTEs"]), max(binsTAB[,"numbGenes"]))
  plot(binsTAB[,1], binsTAB[,3], type="n", xlim = c(start,end), ylim = ylim, xaxt="n", xlab="", ylab = "", bty = "n", yaxt ="n")
  polygon(c(binsTAB[,1], rev(binsTAB[,1])), c(binsTAB[,3], rep(0, nrow(binsTAB))), col = "navyblue", border=NA, lwd = 1)
  polygon(c(binsTAB[,1], rev(binsTAB[,1])), c(-binsTAB[,4], rep(0, nrow(binsTAB))), col = "firebrick2", border=NA, lwd = 1)
  legend("topright", legend = c("Genes", "Transposable Elements"), pch = 17, col = c("navyblue","firebrick2"))
}


f.get.meth.data.from.methylKit.subset <- function(filePATH = "a file path", chromosome, regionStart, regionEnd){
	df <- read.table(text=system(paste0("awk 'OFS=\"\\t\" {if($2 ==  \"",chromosome,"\""," && $3 > ",regionStart," && $3 < ",regionEnd,") {print $0}}\' ",filePATH, sep = ""),intern = TRUE), sep = "\t")[,2:7]
	colnames(df) <- c("chr","base","strand","coverage","freqC","freqT")
	return(df)
}



f.chromosome.plotter.methylation <- function(binsize=1e5,sampleID, binnedDataInput, chromCoordInput = NULL, OUTpath, magnFAC=5, context = "CG", showSpecificFeatures = FALSE, specificFeatures = list()){

	chromosomes <- c("Chr1","Chr2","Chr3","Chr4","Chr5")

	chromLength <- list(
		Chr1 = 30427671,
		Chr2 = 19698289,
		Chr3 = 23459830,
		Chr4 = 18585056,
		Chr5 = 26975502#,
		#ChrM = 366924,
		#ChrC = 154478
	)

	chromLines <- list(
		Chr1 = c(1,30427671),
		Chr2 = c(1,19698289),
		Chr3 = c(1,23459830),
		Chr4 = c(1,18585056),
		Chr5 = c(1,26975502)
	)


	centromerePos <- list(
		Chr1 = 15088987,
		Chr2 = 3608426.5,
		Chr3 = 13591999.5,
		Chr4 = 3956518.5,
		Chr5 = 11742754.5
	)

	yPosChrom <- list(
		Chr1 = c(9,9),
		Chr2 = c(7,7),
		Chr3 = c(5,5),
		Chr4 = c(3,3),
		Chr5 = c(1,1)
	)

	chromCol <- list(
		Chr1 = rgb(215,25,28,150,max=255),
		Chr2 = rgb(253,174,97,150,max=255),
		Chr3 = rgb(255,255,191,150,max=255),
		Chr4 = rgb(171,217,233,150,max=255),
		Chr5 = rgb(44,123,182,150,max=255)
	)

	periList <- list(
		Chr1 = c(13e6,17e6),
		Chr2 = c(2e6,5e6),
		Chr3 = c(11.5e6,15.5e6),
		Chr4 = c(3e6,5e6),
		Chr5 = c(10e6,14e6)
	)


	PLOTout <- OUTpath

	BINSIZE <- binsize

	bins <- list()

	xAxisLabels <- as.character(seq(0,30,by=5))
	xAxisAt <- seq(0,3e7,by=5e6)

	KNOB <- c(1560561,2082885)

	outFileName <- paste(PLOTout,sampleID,"_",BINSIZE/1000,"_",context,"_kb_mehylationLevel",sep="")
	svg(paste(outFileName,".svg", sep = ""),width=14,height=7)
	
	plot(seq(1,3e7,by = 3e6),c(1:10), xlim=c(-3e6,chromLength[["Chr1"]]+3e6),type="n",bty="n",ylab="",xlab="chromosomal position (Mb)", ylim=c(0,max(unlist(yPosChrom))+2),yaxt="n",xaxt="n", main=paste(sampleID,context,sep=" "))
	
	for (Chr in chromosomes){
		if (!missing(binnedDataInput)){
			binnedDataInputSub <- binnedDataInput[binnedDataInput$chrom==Chr,]
			xPOS <- rowMeans(cbind(binnedDataInputSub$start,binnedDataInputSub$end))
			yPOS <- (as.numeric(binnedDataInputSub[,context])/2)*1.5 ## *1.5 to blow it up a bit....
			yPOS[c(1,length(yPOS))] <- 0
			polygon(xPOS,(yPOS)+yPosChrom[[Chr]][1], col = rgb(100,100,100,200,max=255), border=NA)
			axis(2, at=seq(yPosChrom[[Chr]][1], yPosChrom[[Chr]][1]+1.5, length.out=5), labels=seq(0,100, length.out=5))
		}
		if (!is.null(chromCoordInput)){
			chromCoordInputSub <- subset(chromCoordInput,chrom==Chr)
			logFCx <- chromCoordInputSub$start
			logFCyFill <- as.numeric(log(chromCoordInputSub[,5]+1))/5
			logFCyFill[c(1,length(logFCyFill))] <- 0
			polygon(logFCx,(logFCyFill)+yPosChrom[[Chr]][1], col = rgb(100,100,100,200,max=255), border=NA)
			
		}
		
		lines(x=chromLines[[Chr]],y=yPosChrom[[Chr]],lwd=10, col=chromCol[[Chr]])
		lines(x=periList[[Chr]],y=yPosChrom[[Chr]],lwd=10, col="grey")
		lines(x=KNOB,y=yPosChrom[["Chr4"]],lwd=10, col="grey")
		lines(x=c(-2e6,0),y=yPosChrom[["Chr4"]],lwd=10, col="darkorchid4",lend=1,lty=1)
		lines(x=c(-2e6,0),y=yPosChrom[["Chr2"]],lwd=10, col="darkorchid4",lend=1,lty=1)
		if (showSpecificFeatures){
			for (feat in names(specificFeatures)){
				sub <- specificFeatures[[feat]][specificFeatures[[feat]]$chrom == Chr,]
				points(sub$pos,rep(yPosChrom[[Chr]][1],nrow(sub)),pch=17, col = "blue", cex=2)
			}
		}
		points(centromerePos[[Chr]],yPosChrom[[Chr]][1],pch=16, cex=2, col="black")

	}
	axis(side=1,at=xAxisAt, labels=xAxisLabels)
	#legend(x=2.6e7,y=yPosChrom[["Chr3"]][1],legend=c(TRACK1,TRACK2,"centromere","heterochromatin","NOR"),lwd=1, lty=c(1,NA,NA,NA,NA),pch=c(NA,17,16,15,15), col=c(rgb(100,100,100,100,max=255),"red","black","grey","darkorchid4"), bty="n",pt.cex=1.5)
	text(x=rep(-3e6,5),y=unique(unlist(yPosChrom)),labels=chromosomes)
	dev.off()
	system(paste("rsvg-convert -a -p 300 -d 300 ", paste(outFileName, ".svg", sep=""), " > ", paste(outFileName, ".png", sep=""), sep=""))
	
}
