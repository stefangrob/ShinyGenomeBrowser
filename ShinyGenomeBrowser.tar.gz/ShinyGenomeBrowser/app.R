
## load required packages
require(shiny)
require(shinythemes)
require(shinyFiles)
require(plyr)  
require(dplyr)
require(readr)
#require(HiCdatR)

## load local functions
source("./ShinyFunctions.R")


max_plots <- 12

ui6 <- fluidPage(theme = shinytheme("slate"),
	sidebarLayout(position = "left",
		sidebarPanel(
			selectInput(inputId = "numbTracks", label = "how many tracks?", choices = c(1:max_plots)),
			shinyFilesButton(id = "annoFile", label = "select GFF annotation", multiple = FALSE, title = "BROWSE"),
			uiOutput("VarsInput"),
			textInput(inputId = "chrom", label = "Chromosome", value = "Chr1"),
			numericInput(inputId = "start", label = "from", value = 0.7e4, min = 0, step = 500),
			numericInput(inputId = "end", label = "to", value = 2e4, min =0, step = 500),
			actionButton("minus", "5kb to the left"),
			actionButton("plus", "5kb to the right"),
			actionButton("zi", "zoom in"),
			actionButton("zo", "zoom out"),
			sliderInput(inputId = "plotHeight", label = "plotHeight", min = 0, max = 500, value = 180),
			downloadButton(outputId = "down", label = "Download the plot")
		),
		mainPanel(
			uiOutput("plots"),
			plotOutput("anno", height = 180, width = 1160,hover = hoverOpts(id ="plot_hover")),
			verbatimTextOutput("debug"),
			htmlOutput("hover_info")
		)
	)
)


server6 <- function(input, output, session){
	v <- reactiveValues(data = 500)
	observeEvent(input$start,{v$start <- input$start})
	observeEvent(input$end,{v$end <- input$end})
	observeEvent(input$plus, {
		v$start <- input$start + 5000
		v$end <- input$end + 5000
		updateSliderInput(session,"start", value = v$start)
		updateSliderInput(session,"end", value = v$end)
	})
  
	observeEvent(input$minus, {
		v$start <- input$start - 5000
		v$end <- input$end - 5000
		updateSliderInput(session,"start", value = v$start)
		updateSliderInput(session,"end", value = v$end)
	})  
	observeEvent(input$zi, {
		v$start <- input$start + round(0.1*(input$end-input$start))
		v$end <- input$end - round(0.1*(input$end-input$start))
		updateSliderInput(session, "start", value = v$start)
		updateSliderInput(session, "end", value = v$end)
	})
	observeEvent(input$zo, {
		v$start <- input$start - round(0.1*(input$end-input$start))
		v$end <- input$end + round(0.1*(input$end-input$start))
		updateSliderInput(session, "start", value = v$start)
		updateSliderInput(session, "end", value = v$end)
	})
  
	K <- reactive({input$numbTracks})
	output$VarsInput <- renderUI({
		NoV = K()
		T = sapply(1:NoV, function(i){paste0("type",i)})
		Y = sapply(1:NoV, function(i){paste0("YLIM",i)})
		br = sapply(1:NoV, function(i){paste0("browser",i)})
		output = tagList()
		for(i in seq_along(1:NoV)){
			output[[i]] = tagList()
			output[[i]][[1]] = shinyFilesButton(id = br[i], label = paste("Select File Number", i), multiple = FALSE, title = "BROWSE")
			output[[i]][[2]] = radioButtons(inputId = T[i], label = paste("SeqType ",i), choices = c("sRNA","mRNA"), inline = TRUE)
			output[[i]][[3]] = sliderInput(inputId = Y[i], label = "Set ylim", min = 0, max = 10, value = 0)
		} ## for loop
		output
	})
	output$plots <- renderUI({
		k <- as.integer(input$numbTracks)
		plot_output_list <- lapply(1:k, function(i) {
		plotname <- paste("plot", i, sep="")
		plotOutput(plotname, height = input$plotHeight, width = 1160)
		})
    # Convert the list to a tagList - this is necessary for the list of items to display properly.
		do.call(tagList, plot_output_list)
	})
	for (i in 1:max_plots) {
    # Need local so that each item gets its own number. Without it, the value
    # of i in the renderPlot() will be the same across all instances, because
    # of when the expression is evaluated.
		local({
			my_i <- i
			plotname <- paste("plot", my_i, sep="")
			shinyFileChoose(input, paste("browser", my_i, sep =""),roots=c(wd='/'), filetypes=c('bed', 'bam'),defaultPath='/home', restrictions = c("/bin", "/boot", "/dev", "/etc", "/lib", "/lib32", "/lib64", "/opt", "/proc", "/run", "/sbin", "/snap", "/sys", "/usr", "/var", "/root", "/srv", "/tmp", "/mnt", "/lost+found", "/cdrom"))
			fileToChoose <- reactive(input[[paste("browser", my_i, sep ="")]])      
			output[[plotname]] <- renderPlot({
				if (input[[paste("YLIM", my_i, sep ="")]] == 0){ylim = NULL}
				else {ylim = input[[paste("YLIM", my_i, sep ="")]]}
				#convert the path from the shinyFileChoose (has to be done within a render function...)
				pathInfo <- unlist(fileToChoose()[["files"]])
				pathInfo <- paste(pathInfo[1:length(pathInfo)], collapse = .Platform$file.sep)
				bam <- pathInfo
				p <- f.reads.extract.minimal(chrom = input$chrom, start = v$start, end = v$end, bamPATHin = bam, threads = 4)
				libSize <- f.library.size(bam)
				if (input[[paste("type",my_i, sep="")]] == "sRNA"){ ##trying to select sRNA or mRNA...
					par(mar = c(0,2,0,2))
					if ((as.numeric(v$end) - as.numeric(v$start)) > 5e4){
						f.binned.plotter.minimal(bam, binsize = NULL, chr = input$chrom, start = v$start, end = v$end, xlim = c(v$start, v$end), ylimit = ylim, main = paste("BAM", my_i, sep =""), rpm = TRUE)
					} else {
						f.coverage.plotter(inDAT = p, stranded=TRUE, sizes=c(21,22,23,24), rpm = TRUE, TotLibReads = libSize, start = v$start, end = v$end, ylim = ylim, title = paste("BAM", my_i, sep =""), normFac = NULL)
					}
				}
				else {
					par(mar = c(0,2,0,2))
					if ((as.numeric(v$end) - as.numeric(v$start)) > 5e4){
						f.binned.plotter.minimal(bam, binsize = NULL, chr = input$chrom, start = v$start, end = v$end, xlim = c(v$start, v$end), ylimit = ylim, main = paste("BAM", my_i, sep =""), rpm = TRUE)
					} else {
						f.coverage.plotter.mRNA(inDAT = p, stranded=FALSE, rpm = TRUE, TotLibReads = libSize, start=v$start, end=v$end, ylim=ylim, title = "george", normFac=NULL, colors = c("navyblue","firebrick2"))
					}
				}
			})
		})
	}
  
  #loading the gff...
	shinyFileChoose(input, "annoFile",roots=c(wd='/'), filetypes=c('gff', 'GFF'),defaultPath='/home', restrictions = c("/bin", "/boot", "/dev", "/etc", "/lib", "/lib32", "/lib64", "/opt", "/proc", "/run", "/sbin", "/snap", "/sys", "/usr", "/var", "/root", "/srv", "/tmp", "/mnt", "/lost+found", "/cdrom"))
	anno <- reactive(input$annoFile)
	output$anno <- renderPlot({
		anno <- unlist(anno()[["files"]])
		anno <- paste(anno[1:length(anno)], collapse = .Platform$file.sep)
		an <- anno
		an <- f.gff.loader(gffPATH = an, chrom = input$chrom, start = v$start, end = v$end, featureOI = c("gene", "transposable_element_gene","transposable_element", "pseudogene", "miRNA", "ncRNA", "snoRNA", "tRNA", "rRNA", "exon"))
		v$an <- an
		par(mar = c(5,2,0,2))
		if ((as.numeric(v$end) - as.numeric(v$start)) > 1e6) {
			f.plot.gff.anno.binned(gff = an, chrom = input$chrom, start = v$start, end = v$end, binsize = NULL)
		} else {
			if ((as.numeric(v$end) - as.numeric(v$start)) < 5e4){genelabel = TRUE} else {genelabel = FALSE}
			f.plot.gff.anno(chrom = input$chrom, start = v$start, end = v$end, gff = an,label = genelabel)
		}
	})

	output$hover_info <- renderUI({
		if(!is.null(input$plot_hover)){
			hover=input$plot_hover
			x <- round(as.numeric(hover$x))
			posRange <- (x-3000):(x+3000) #3000 is the minimal distance one needs
			inRange <- v$an[v$an[["start"]] %in% posRange | v$an[["end"]] %in% posRange & v$an[["feature"]] != "exon" & v$an[["seqname"]] == as.character(input$chrom), ]
			dist <- as.data.frame(cbind(abs(x-inRange$start), abs(x-inRange$end)))
			GeneName <- inRange[which.min(apply(dist,1,min)),"name"]#get the rownumber with the minimal value in the apply..
			toPrint <- paste("<b>",GeneName,"</b>")
			if (!is.na(GeneName)){toPrint <- paste("<b>",GeneName,"</b>",f.retrieve.gene.info(GeneName), sep = "\n")}
			HTML(toPrint)
		}
	})
	output$down <- downloadHandler(
		filename =  function() {
			paste(".pdf")
		},
	# content is a function with argument file. content writes the plot to the device
		content = function(file) {
			pdf(file, width = 14) # open the pdf device
			par(mfrow = c(2,1))
			for (i in 1:K()) {
				local({
					my_i <- i
					plotname <- paste("plot", my_i, sep="")
					shinyFileChoose(input, paste("browser", my_i, sep =""),roots=c(wd='/'), filetypes=c('bed', 'bam'),defaultPath='/home', restrictions = c("/bin", "/boot", "/dev", "/etc", "/lib", "/lib32", "/lib64", "/opt", "/proc", "/run", "/sbin", "/snap", "/sys", "/usr", "/var", "/root", "/srv", "/tmp", "/mnt", "/lost+found", "/cdrom"))
					fileToChoose <- reactive(input[[paste("browser", my_i, sep ="")]])
					if (input[[paste("YLIM", my_i, sep ="")]] == 0){ylim = NULL}
					else {ylim = input[[paste("YLIM", my_i, sep ="")]]}
					pathInfo <- unlist(fileToChoose()[["files"]])
					pathInfo <- paste(pathInfo[1:length(pathInfo)], collapse = .Platform$file.sep)
					bam <- pathInfo
					p <- f.reads.extract.minimal(chrom = input$chrom, start = v$start, end = v$end, bamPATHin = bam, threads = 4)
					libSize <- f.library.size(bam)
					if (input[[paste("type",my_i, sep="")]] == "sRNA"){ ##trying to select sRNA or mRNA...
						par(mar = c(0,2,0,2))
						if ((as.numeric(v$end) - as.numeric(v$start)) > 5e4){
							f.binned.plotter.minimal(bam, binsize = NULL, chr = input$chrom, start = v$start, end = v$end, xlim = c(v$start, v$end), ylimit = ylim, main = paste("BAM", my_i, sep =""), rpm = TRUE)
						} else {
							f.coverage.plotter(inDAT = p, stranded=TRUE, sizes=c(21,22,23,24), rpm = TRUE, TotLibReads = libSize, start = v$start, end = v$end, ylim = ylim, title = paste("BAM", my_i, sep =""), normFac = NULL)
						}
					}
					else {
						par(mar = c(0,2,0,2))
						if ((as.numeric(v$end) - as.numeric(v$start)) > 5e4){
							f.binned.plotter.minimal(bam, binsize = NULL, chr = input$chrom, start = v$start, end = v$end, xlim = c(v$start, v$end), ylimit = ylim, main = paste("BAM", my_i, sep =""), rpm = TRUE)
						} else {
							f.coverage.plotter.mRNA(inDAT = p, stranded=FALSE, rpm = TRUE, TotLibReads = libSize, start=v$start, end=v$end, ylim=ylim, title = "george", normFac=NULL, colors = c("navyblue","firebrick2"))
						}
					}
				})
			}
		f.plot.gff.anno(chrom = input$chrom, start = v$start, end = v$end, gff = v$an,label = TRUE)
		dev.off() 
		} 
	)
}

shinyApp(ui = ui6, server = server6)


